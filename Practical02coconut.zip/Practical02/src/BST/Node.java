package BST;

class Node<T extends Comparable<T>> implements Comparable {
	T key; 
	int height;
	Node<T> left, right;

	Node(T d) {
		key = d;
		height = 1;
	}

	@Override
	public int compareTo(Object o) {
		if (o instanceof Node) {
			Node<T> n = (Node<T>)o;
			this.key.compareTo(n.key);
		} else {
			T obj = (T)o;
			return this.key.compareTo(obj);
		}
		return Integer.MAX_VALUE;
	}

	T max(Node<T> other) {
		if(other.key.compareTo(this.key) > 1)
			return other.key;
		return this.key;
	}

	@Override
	public String toString() {
		return "{Key: " + this.key + "}";
	}

}
