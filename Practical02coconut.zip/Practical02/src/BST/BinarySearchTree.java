package BST;

public class BinarySearchTree<T extends Comparable<T>> {
	
	Node<T> root;

	public BinarySearchTree() {
	}

	public BinarySearchTree(T data) {
		root = new Node<T>(data);
	}
	
	// Insert key into the tree.
	public void insert(T key) {
		// if the current node is null its time to add the next node
		if (this.root == null) {
			root = new Node<T>(key);
		} else {
			this.root = insert(this.root, key);
		}
	}

	// Insert key recursively into the subtree rooted with currentNode.
	// Return the root of the subtree after insertion.
	Node<T> insert(Node<T> currentNode, T key) {
    // 如果当前节点为空，则创建一个新节点并返回
    if (currentNode == null) {
        return new Node<T>(key);
    }
    
    // 递归地确定新节点应该插入到左子树还是右子树
    // 如果 key 小于当前节点值，则插入到左子树
    if (currentNode.compareTo(key) > 0) {
        currentNode.left = insert(currentNode.left, key);
    } 
    // 如果 key 大于当前节点值，则插入到右子树
    else if (currentNode.compareTo(key) < 0) {
        currentNode.right = insert(currentNode.right, key);
    } 
    // 如果 key 等于当前节点值，则不插入，直接返回当前节点
    else {
        return currentNode;
    }

    // 更新当前节点的高度
    // 计算左子树和右子树的高度，取较大值加 1 作为当前节点的新高度
    currentNode.height = 1 + Math.max(
        (currentNode.left != null ? currentNode.left.height : 0),
        (currentNode.right != null ? currentNode.right.height : 0)
    );
    
    // 返回当前子树的根节点
    return currentNode;
}

	// Recursively construct a string showing in-order traversal of the tree.
	private String inOrderString(Node<T> node) {
		String output = "";
		if (node != null) {
			output += inOrderString(node.left);
			output += node.toString();
			output += inOrderString(node.right);
		}
		return output;
	}

	// Recursively construct a string showing pre-order traversal of the tree.
	private String preOrderString(Node<T> node) {
    // 使用 StringBuilder 来提高字符串拼接效率
    StringBuilder output = new StringBuilder();
    
    // 递归进行先序遍历：根 -> 左子树 -> 右子树
    if (node != null) {
        output.append(node.toString()); // 访问当前节点
        output.append(preOrderString(node.left)); // 递归访问左子树
        output.append(preOrderString(node.right)); // 递归访问右子树
    }
    
    return output.toString(); // 返回最终的字符串表示
}
	@Override
	public String toString() {
		String output = "** Binary Search Tree **" + "\n";

		output += "Tree Height : " + this.root.height + "\n";
		output += "In order traversal: \n" + this.inOrderString(root) + "\n";
		output += "Pre order traversal: \n" + this.preOrderString(root) + "\n";

		return output;
	}

}
