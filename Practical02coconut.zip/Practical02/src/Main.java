import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Main {
	public static void main(String[] args) {
		
		// BST Tree with numbers. 
	    /* Construct a BST:
	     * 	    10
	     *        \
	     *        20
	     *          \
	     *          30
	     *          / \
	     *         25 40
	     *              \
	     *              50
	     */
		BST.BinarySearchTree<Integer> tree = new BST.BinarySearchTree<Integer>();
		tree.insert(10);
		tree.insert(20);
	    tree.insert(30);
	    tree.insert(40);
	    tree.insert(50);
	    tree.insert(25);
	    System.out.println(tree.toString());

	    /* Construct another BST:
	     *      30
	     *     /  \
	     *    20  40
	     *   /  \   \
	     *  10  25  50
	     */
	    BST.BinarySearchTree<Integer> tree2 = new BST.BinarySearchTree<Integer>();
	    tree2.insert(30);
	    tree2.insert(20);
	    tree2.insert(40);
	    tree2.insert(50);
	    tree2.insert(10);
	    tree2.insert(25);
	    System.out.println(tree2.toString());
	    
	    
	    // BST Tree with strings.
	    /* Construct a BST:
	     *       Mandy
	     *       /   \
	     *     Alf   Mindy
	     *              \
	     *              Murphy
	     *                  \
	     *                  Murry
	     *                     \
	     *                     Pete
	     */
	    BST.BinarySearchTree<String> sTree = new BST.BinarySearchTree<String>();
	    sTree.insert("Mandy");
	    sTree.insert("Mindy");
	    sTree.insert("Murphy");
	    sTree.insert("Murry");
	    sTree.insert("Alf");
	    sTree.insert("Pete");
	    System.out.println(sTree.toString());

	    /* Construct another BST: 
	     *        Mindy
	     *         /  \
	     *     Mandy   Murry
	     *     /       /   \
	     *    Alf   Murphy  Pete
	     */
	    BST.BinarySearchTree<String> sTree2 = new BST.BinarySearchTree<String>();
	    sTree2.insert("Mindy");
	    sTree2.insert("Mandy");
	    sTree2.insert("Murry");
	    sTree2.insert("Pete");
	    sTree2.insert("Alf");
	    sTree2.insert("Murphy");
	    System.out.println(sTree2.toString());
	    
	}
}
